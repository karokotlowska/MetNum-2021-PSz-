#include <stdio.h>
#include <math.h>


///!!!!nie wiem jak dzielic przedzial

double f(double x){
    return log(x)*(x-2)*(x-2);
}

double f_pochodna(double x){
    return (x-2)*(x-2)/(x) + log(x)*2*(x-2);
}

void newton(double x, double e0, FILE *f1)
{
    double x_i = 0;
    for(int k=1; fabs(x-x_i) > e0 ; k++)
    {
        x_i =x;
        x=x-f(x)/f_pochodna(x);
        fprintf(f1, "%f %f %f %f\n", x, fabs(x-x_i), f(x), f_pochodna(x));
    }
    fprintf(f1, "\n");
}

void newton_z_k(double x, double e0,int r, FILE *f1)
{
    double x_i = 0;
    for(int k=1; fabs(x-x_i) > e0 ; k++)
    {
        x_i =x;
        x=x-r*(f(x)/f_pochodna(x));
        fprintf(f1, "%f %f %f %f\n", x, fabs(x-x_i), f(x), f_pochodna(x));
    }
    fprintf(f1, "\n");
}
double u(double x)
{
    return f(x)/f_pochodna(x);
}
double u_pochodna(double x)
{
    return ((-2 + x)*(-2 + x) + (-2 + x)*(-2 + x) *log(x) + 2* x*x*log(x)*log(x))/((-2 + x + 2 *x *log(x))*(-2 + x + 2 *x *log(x)));
}

void newton_n_z_k(double x, double e0, FILE *f1)
{
    double x_i = 0;
    for(int k=1; fabs(x-x_i) > e0 ; k++)
    {
        x_i =x;
        x=x-(u(x)/u_pochodna(x));
        fprintf(f1, "%f %f %f %f\n", x, fabs(x-x_i), f(x), f_pochodna(x));
    }
    fprintf(f1, "\n");
}

int main(){
    FILE *f1 =fopen("wyn.dat", "w");
    fprintf(f1, "%s\n", "\nPierwszy pierwiastek: ");
    newton(0.5, 10e-6, f1);
    fprintf(f1, "%s\n", "\nDrugi pierwiastek bez modyfikacji: ");
    newton(1.4, 10e-6, f1);
    fprintf(f1, "%s\n", "\nDrugi pierwiastek gdy znam krotnosc: ");
    newton_z_k(1.4, 10e-6,2,  f1);
    fprintf(f1, "%s\n", "\nDrugi pierwiastek gdy nieznam krotnosci: ");
    newton_n_z_k(1.4, 10e-6,  f1);
    fclose(f1);
    return 0;
}