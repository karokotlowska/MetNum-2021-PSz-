#include <stdio.h>
#include <math.h>


///!!!!nie wiem jak dzielic przedzial
//Wyznaczanie pierwiastków równania nieliniowego metodami siecznych i Newtona. Badanie szybkości zbieżności metody. -zadB
//https://github.com/Blinkuu/wfiis-mn-2019/blob/master/lab06/main.cpp
double f1(double x)
{
  return pow((log(x)-x), 6)-1;
}

double f_p1(double x)
{
  return 6*pow((log(x)-x), 5) *(1/x -1 );
}
double f2(double x)
{
  return pow(x,3)+2*pow(x,2)-3*x+4;
}

double f_p2(double x)
{
  return 3*pow(x,2)+4*x-3;
}

void newton(double x, FILE *f1, double f(double), double f_pochodna(double))
{
  double x_i = 0;
  double eps = fabs(x-x_i);
  double eps_p=eps;
  double eps_pp=eps;
  double p=0;
  for(int k=0; k<20 ; k++)
  {
    x_i =x;
    x=x-f(x)/f_pochodna(x);
    eps =fabs(x_i - x);
    if(k>=2){
      p=(log(eps_p/eps)/log(eps_pp/eps_p));
    }
    eps_pp=eps_p;
    eps_p=eps; 
    
    fprintf(f1, "%d %25.25f %25.25f %25.25f %25.25f\n",k+1,f(x), x, eps, p);
  }
  fprintf(f1, "\n");
}

/*
std::array<double, 22> x = {};
    std::array<double, 22> epsi = {};
    std::array<double, 22> zbieznosci = {};

    x[0] = xm1;
    x[1] = x0;

    epsi[0] = epsiValue(x[0], xd);
    epsi[1] = epsiValue(x[1], xd);
 for (int i = 2; i < n; i++) {
        double xPrevPrev = func(x[i - 2]);
        double xPrev = func(x[i - 1]);
        x[i] = x[i - 1] - ((xPrev * (x[i - 1] - x[i - 2])) / (xPrev - xPrevPrev));
        epsi[i] = epsiValue(x[i], xd);
        zbieznosci[i] = zbieznosc(epsi[i], epsi[i - 1], epsi[i - 2]);
        saveToFile(fileName, i - 1, xPrev, x[i - 1], epsi[i], zbieznosci[i], true);
    }
}

void newton(std::function<double(double)> func, std::function<double(double)> func_der, double real_zero, double start)
{
	std::ofstream newton;
	newton.open("newton.txt");

	int i = 0;
	double x_zero = start;
	while(i++ < MAX_ITER)
	{
		double e_before = epsilon(x_zero, real_zero);
		x_zero = x_zero - func(x_zero)/func_der(x_zero);
		double e_now = epsilon(x_zero, real_zero);

		double for_next = x_zero - func(x_zero)/func_der(x_zero);

		double e_next = epsilon(for_next, real_zero);

		newton << i << "\t" << std::setprecision(15) << func(x_zero) << "\t" << x_zero << "\t" << e_now << "\t" << p(e_before, e_now, e_next) << std::endl;
		std::cout << x_zero << '\n'; 

   /////// double p(double e0, double e1, double e2) 
{
	return log(e1/e2)/log(e0/e1);
<<<<<<< HEAD
=======
}
	}

	newton.close();
}*/


void sieczna(double x0, double x1, FILE *f1, double f(double x), double f_pochodna(double x))
{
  double x2 = 0; 
  double eps = fabs(x1-x0);
  double eps_p=eps;
  double eps_pp=eps;
  double p=0;
  for(int k=0; k<20 ; k++)
  { 
    x2 = x1 - ((f(x1)*(x1-x0))/(f(x1)-f(x0)));   
    eps =fabs(x2 - x1);
    if(k>=2){
      p=(log(eps_p/eps)/log(eps_pp/eps_p));
    }
    eps_pp=eps_p;
    eps_p=eps; 
    fprintf(f1, "%d %25.25f %25.25f %25.25f %25.25f\n",k+1,f(x2), x2, eps, p);
    x0 = x1;
    x1 = x2;   
  }
  fprintf(f1, "\n");
}

int main()
{
  FILE *f = fopen("wyn.dat", "w");
  fprintf(f, "%s\n", "\nFunkcja f, newton ");
  newton(3.0, f, f1, f_p1 );
  fprintf(f, "%s\n", "\nFunkcja f, sieczna ");
  sieczna(3.0, 3.01, f, f1, f_p1);
  fprintf(f, "%s\n", "\nFunkcja g, newton ");
  newton(-20.0, f, f2, f_p2 );
  fprintf(f, "%s\n", "\nFunkcja g, sieczna ");
  sieczna(-20.0, -20.01, f, f2, f_p2);
  fclose(f);
  return 0;
}