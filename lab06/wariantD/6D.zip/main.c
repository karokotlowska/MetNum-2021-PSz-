#include <stdio.h>
#include <math.h>
/*https://github.com/marroko/numerical-methods/blob/master/lab06/main.cpp*/
double f(double x){
    return (x-1.2)*(x-2.3)*(x-3.3)*(x-3.3);
}

void sieczna(double x0, double x1, double e0, FILE *f1){
    double x2 = 0; 
    double eps = fabs(x1-x0);
    for(int k=1; k<=10000 ; k++){

        
        x2 = x1 - ((f(x1)*(x1-x0))/(f(x1)-f(x0))); 
        //printf("%g %g  %g \n" , x2, x1,  (f(x1)*(x1-x0))/(f(x1)-f(x0)));
        eps =fabs(x2 - x1);
        
        fprintf(f1, "%d %g %g %g \n",k, x2, eps, f(x2));
        if(fabs(x2 - x1) < pow(10, -6)){
           break;
       } 
        x0 = x1;
        x1 = x2;
        
    }
    fprintf(f1, "\n");
}

double f_poch_d1(double x){ //pochodna delta = 0,1
    double d= 0.1;
    return (f(x+d)-f(x-d))/(2*d);

}
double f_poch_d2(double x){ //pochodna delta = 0,001
    double d= 0.001;
    return (f(x+d)-f(x-d))/(2*d);

}

double u(double x, double f_pochodna(double x) ){
    return (f(x))/(f_pochodna(x));
}

void sieczna_krotnosc(double x0,double x1, double e0, FILE *f1, double f_pochodna(double x)){
    double x2 = 0; 
     double eps = fabs(x1-x0);
    for(int k=1; k<=10000 ; k++){

        //printf("%g\n", fabs(x2-x1));
        x2= x1 - (u(x1, f_pochodna)*(x1-x0))/(u(x1, f_pochodna)-u(x0, f_pochodna)); 
        eps =fabs(x2 - x1);
         
        fprintf(f1, "%d %g %g %g \n", k, x2, fabs(x2 - x1), f(x2));
        if(fabs(x2 - x1) < pow(10, -6)){
            break;
        } 
        x0 = x1;
        x1 = x2;
    }
    fprintf(f1, "\n");
}

int main(){
    FILE *f1 =fopen("wyn.dat", "w");
    fprintf(f1, "%s\n", "\nPierwszy pierwiastek: ");
    sieczna(0.9, 1.0, 10e-6, f1);
    fprintf(f1, "%s\n", "\nDrugi pierwiastek: ");
    sieczna(1.7, 1.75, 10e-6, f1);
    fprintf(f1, "%s\n", "\nTrzeci pierwiastek: ");
    sieczna(3.7, 3.65, 10e-6, f1);
    fprintf(f1, "%s\n", "\nTrzeci pierwiastek gdy pochodna wyznaczona, delta = 0,1: ");
    sieczna_krotnosc(3.7, 3.65, 10e-6,  f1, f_poch_d1);
    fprintf(f1, "%s\n", "\nTrzeci pierwiastek gdy pochodna wyznaczona, delta = 0,001: ");
    sieczna_krotnosc(3.7, 3.65, 10e-6,  f1, f_poch_d2);
    fclose(f1);    
}

// wyniki
// http://galaxy.agh.edu.pl/~estrzalk/mn/gr6/lab_6_wyniki.pdf
