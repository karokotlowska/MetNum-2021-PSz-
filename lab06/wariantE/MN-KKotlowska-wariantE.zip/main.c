#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 5
#define IT_MAX 30

double licz_r (double *a, double *b,int n,double xj)
{
	b[n] = 0;
	for(int i = n-1; i >= 0; i--)
		b[i] = a[i+1] + xj*b[i+1];
	return a[0] + xj*b[0];
}


int main(void) {
double x0, x1, Rit,Rit2;
double* a = malloc((N+1)*sizeof(double));
double* b = malloc((N+1)*sizeof(double));
double* c = malloc((N+1)*sizeof(double));
int n;
FILE* f = fopen("out.dat", "w");
FILE* fp=fopen("pierwiastki.dat","w");
a[0] = 240.0;
a[1] = -196.0;
a[2] = -92.0;
a[3] = 33.0;
a[4] = 14.0;
a[5] = 1.0;
fprintf(f,"L --------- it --------- x1 --------- Rit --------- Rit2\n");
for (int L=1;L<=N;L++){
  n=N-L+1;
  x0=0;
  for (int i=1;i<=IT_MAX;i++){
    Rit = licz_r(a,b,n,x0);
		Rit2 = licz_r(b,c,n-1,x0);
    x1=x0-Rit/Rit2;
    fprintf(f,"%d ---|--- %d ---|--- %g ---|--- %g ---|--- %g\n",L,i,x1,Rit,Rit2);
    if(fabs(x1-x0)<pow(10,-7)) break;
    x0=x1;
  }
  fprintf(fp,"Pierwiastek: %f\n",x1);
  fprintf(f,"\n\n");
  for (int i=0;i<=n-1;i++) a[i] = b[i];

}
fclose (f);
fclose(fp);
free(a);
free(b);
free(c);
return 0;
}