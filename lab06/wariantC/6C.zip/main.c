#include <stdio.h>
#include <math.h>


///!!!!nie wiem jak dzielic przedzial
//Wyznaczanie pierwiastków równania nieliniowego metodą siecznych -zad C
//https://github.com/Karambusz/MN/blob/master/LAB6/main.c

double f(double x)
{
  return pow(x, 4) - 7.899*pow(x, 3) + 23.281114*pow(x, 2) + 14.73866033 - 30.33468152*x;
} 
double f_p(double x)
{
  return 4*pow(x, 3) - 3*7.899*pow(x, 2) + 2*23.281114*x - 30.33468152;
}

void sieczna(double x0, double x1, double e0, FILE *f1)
{
  double x2 = 0; 
  double eps = fabs(x1-x0);
  for(int k=1; eps > e0 ; k++)
  {
    x2 = x1 - ((f(x1)*(x1-x0))/(f(x1)-f(x0))); 
    //printf("%f %f  %f \n" , x2, x1,  (f(x1)*(x1-x0))/(f(x1)-f(x0)));
    eps =fabs(x2 - x1);
    fprintf(f1, "%f %f %f %f\n", x2, eps, f(x2), f_p(x2));
    x0 = x1;
    x1 = x2;    
  }
    fprintf(f1, "\n");
}

double u(double x, double f_pochodna(double x) )
{
  return (pow(x, 4) - 7.899*pow(x, 3) + 23.281114*pow(x, 2) + 14.73866033 - 30.33468152*x)/(f_pochodna(x));
}

double f_poch_d1(double x)//pochodna delta = 0,1
{
    double d= 0.1;
    return (f(x+d)-f(x-d))/(2*d);
}

double f_poch_d2(double x)//pochodna delta = 0,001
{ 
    double d= 0.001;
    return (f(x+d)-f(x-d))/(2*d);
}


void sieczna_krotnosc(double x0,double x1, double e0, FILE *f1, double f_pochodna(double x))
{
  double x2 = 0; 
  double eps = fabs(x1-x0);
  for(int k=1; eps > e0 ; k++)
  {
    //printf("%f\n", fabs(x2-x1));
    x2= x1 - (u(x1, f_pochodna)*(x1-x0))/(u(x1, f_pochodna)-u(x0, f_pochodna)); 
    eps =fabs(x2 - x1);
    fprintf(f1, "%f %f %f %f\n", x2, fabs(x2 - x1), f(x2), f_pochodna(x2));
    x0 = x1;
    x1 = x2;
  }
    fprintf(f1, "\n");
}
/*void modyfikowanaMetodaSiecznych(double x0, double x1, double delta) {
    double x2 = 0;
    printf("Modyfikowana metoda siecznych dla x0 = %.3f, x1 = %.3f \n", x0, x1);
    for(int k = 1; k <= 10000; k++) {
        x2 = x1 - ((x1 - x0)/(funkcjaU(x1, delta) - funkcjaU(x0, delta))) * funkcjaU(x1, delta);
        printf("k = %d       x2 = %10g         ε = %15g      f(x2) = %15g  \n",k, x2, fabs(x2 - x1), funkcja(x2));
        if(fabs(x2 - x1) < pow(10, -6)){
            break;
        } 
        x0 = x1;
        x1 = x2;
    }
    printf("\n \n");



    modyfikowanaMetodaSiecznych(3.7, 3.65, 0.1); // x0 = 3.7, x1 = 3.65, delta = 0.1
    modyfikowanaMetodaSiecznych(3.7, 3.65, 0.001); // x0 = 3.7, x1 = 3.65, delta = 0.001


// niemodyfikowana 
    std::cout << "x = 1.2\n";
    solution(0.9, 1.0, ptr);
    std::cout << "\nx = 2.3\n";
    solution(1.7, 1.75, ptr);
    std::cout << "\nx = 3.3\n";
    solution(3.7, 3.65, ptr);

     // modyfikowana
    ptr = u;
    std::cout << "\nModyfikowana x = 3.3, delta = 0.1\n";
    solution(3.7, 3.65, ptr);

    // obliczenia dla deltaX = 0.001
    std::cout << "\nModyfikowana x = 3.3, delta = 0.001\n";
    deltaX = 0.001;
    solution(3.7, 3.65, ptr);
}*/
int main()
{
  FILE *f1 =fopen("wyn.dat", "w");
  fprintf(f1, "%s\n", "\nPierwszy pierwiastek: ");
  sieczna(1.49, 1.5, 10e-6, f1); //przedzialy izolacji
  fprintf(f1, "%s\n", "\nDrugi pierwiastek: ");
  sieczna(1.79, 1.8, 10e-6, f1);
  fprintf(f1, "%s\n", "\nTrzeci pierwiastek: ");
  sieczna(2.19, 2.20, 10e-6, f1);//obliczone normalnie

  fprintf(f1, "%s\n", "\nTrzeci pierwiastek gdy pochodna liczona: ");
  sieczna_krotnosc(2.19, 2.20, 10e-6,  f1, f_p);//z normalna pochodna
  fprintf(f1, "%s\n", "\nTrzeci pierwiastek gdy pochodna wyznaczona, delta = 0,1: ");
  sieczna_krotnosc(2.19, 2.20, 10e-6,  f1, f_poch_d1);//z inna pochodna
  fprintf(f1, "%s\n", "\nTrzeci pierwiastek gdy pochodna wyznaczona, delta = 0,001: ");
  sieczna_krotnosc(2.19, 2.20, 10e-6,  f1, f_poch_d2); //z inna pochodna
  fclose(f1);    
  return 0;
}